#include <iostream>
using namespace std; 
int main() { 
   int number,i=0; 
    cout << "How many numbers you want to ask from the user = "; 
    cin>> number; 
    if(number<0) { 
       cout << "Invalid Input, Please enter term greater than 0";
	}
	while(i<number) { 
	  int term, a=0, b=1; 
	  if(i==0) { 
	     cout << "Which Fibonacci = "; 
	  }
	  else if(i== number -1)
	  { 
	    cout << "Which last fibonacci you want to ask for= "; 
	  }
	  else 
	  {
	  	cout << "Which Next Fibonacci= "; 
	  }
	  cin >>term; 
	  if(term>0)
	  { 
	     for(int i=0 ; i<term -1; i++){ 
	         int temp=b; 
	         b = a+b; 
	         a=temp; 
		 }
		 cout << "F" <<term << "is " << b << endl;
		 i++; 
	  }
	}
return 0; 
}
