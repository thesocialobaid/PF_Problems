#include <iostream>
using namespace std;

int main() {
    int n;
    bool is_consec = false;
    cout << "Enter the Number to find the three numbers for = ";
    cin >> n;

    for (int i = 2; i < n - 1 && !is_consec; i++) {
        if (i * (i + 1) * (i - 1) == n) {
            is_consec = true;
            cout << "The Three Consecutive Numbers are = " << i << " , " << (i + 1) << " , " << (i - 1) << endl;
        }
    }

    if (!is_consec) {
        cout << "There are no three consecutive numbers that can be multiplied to get the number" << endl;
    }
	
    return 0;
}
