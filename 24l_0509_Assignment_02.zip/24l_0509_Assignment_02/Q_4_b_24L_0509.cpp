#include<iostream>
using namespace std;

int main(){
    for(int i = 0; i <=1000;i++)
    {
        for(int j = i;j<1000; j++)
        {
            for(int k = j;k<1000;k++)
            {
                if(i + j + k == 1000)
                {
                    cout<<i <<" + "<<j <<" + "<<k <<" = "<<1000<<endl; 
                }
            }
        }        
    }
 return 0;
}

