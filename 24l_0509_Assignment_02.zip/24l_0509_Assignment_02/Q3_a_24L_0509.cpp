#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int number;
    bool check_flag;

    do {
        cout << "Enter the number to check if it is a perfect square = ";
        cin >> number;
        check_flag = false; 

        for (int i = 1; i * i <= number && check_flag == false; i++) {
            if (number == i * i) {
                check_flag = true;
            }
        }

        if (check_flag == true) {
            cout << "The Number is a perfect square " << endl;
        } else {
            cout << "The Number is not a perfect square " << endl;
        }
    } while (number != -1);

    return 0;
}
