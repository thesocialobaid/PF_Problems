#include<iostream>
using namespace std;

int main(){
    int birth_day, birth_month, birth_year, current_day, current_month, current_year, year, month, day;
    bool flag = true;
    do{ 
        cout << "Enter the Data for your Birth Date: " << endl;
        cout << "Day: ";
        cin >> birth_day;
        cout << "Month: ";
        cin >> birth_month;
        cout << "Year: ";
        cin >> birth_year;
        cout << "Enter the Data for Current Date: " << endl;
        cout << "Day: ";	
        cin >> current_day;
        cout << "Month: ";
        cin >> current_month;
        cout << "Year: ";
        cin >> current_year;
        if(current_month > 12 || current_month < 1 || birth_month > 12 || birth_month < 1)
        {
            flag = false;
            cout << "Invalid month Entry!..." << endl;
        }
        else if(((current_month == 8 || current_month%2 != 0) && (current_day > 31)) || ((birth_month == 8 || birth_month%2 == 1) && (birth_day > 31)) ||(current_month == 2 && current_day>29) || (birth_month == 2 && birth_day>29) || (current_month == 2 && current_day == 29 && current_year%4 != 0)||(birth_month == 2 && birth_day == 29 && birth_year%4 != 0) || (current_month%2 == 0 && current_day>30) || (birth_month%2 == 0 && birth_day>30))
        {
            flag = false;
            cout << "Invalid Day Entry!..." << endl;
        } 
        else if ((current_year < birth_year)||(current_year == birth_year && current_month<birth_month) ||(current_year == birth_year && current_month == birth_month && current_day<birth_day))
        {
            flag = false;
            cout << "Invalid Dates!..." << endl;
        }
    }while(flag == false);
    year = current_year - birth_year ;
    month = current_month - birth_month;
    if((current_month < birth_month)||(current_month == birth_month && current_day<birth_day))
    {
        year --;
        month = month + 12;
    }
    if(month < 0)
    {
        month = month + 12;
    }
    day = 0;
    if(current_day < birth_day)
    {
        if((current_month - 1) == 8 ||(current_month - 1)%2== 1)
        { 
            day = 31;
        }
        else if((current_month-1) == 2 && (current_year % 4 == 0))
        {
            day = 29;
        }
        else if((current_month-1) == 2 && (current_year % 4 != 0))
        {
            day = 28;
        }
        else
        {
            day = 30;
        }
    }
    day = day + current_day - birth_day;
    cout << "You are " << year << " years " << month << " months and " << day << " days old!..." << endl;
    return 0;
}

