#include <iostream>
using namespace std;

int main() {
  int n1, n2,hcf,lcm;
  bool flag = false; 
  cout << "Enter the First Number = "; 
  cin >> n1; 
  cout << "Enter the Second Number = "; 
  cin >> n2;
  hcf = n1;
  if(n2<n1)
    hcf = n2; 
  while(flag == false)
  {
    if(n1%hcf == 0 && n2%hcf == 0)
    flag = true;
    else
    {
      hcf--;
    }
  }
   lcm = n1*n2/hcf;
  	cout << "The LCM of the two numbers is = "<< lcm<< endl; 
	return 0; 
}

