#include <iostream>
using namespace std; 
int main() { 
   int number, first=0,second=1; 
   int next; 
   cout << "You want to print up to = "; 
   cin >> number; 
   
   if(number <0) { 
      cout << "The number must be greater than 0"; 
   }
   
   
   cout << "The Sequence Up to <" << number << " is : "; 
    while(second< number) { 
       next = second; 
       second = first + second; 
       first = next; 
       cout << first << " "; 
	}  
return 0; 
}
