#include <iostream>
using namespace std; 
int main() { 
 int sum=0, first=0, second=1, next; 
 
 while(sum <=4000000) { 
    next =second; 
    second = first + second; 
    first = next; 
    if(first%2 ==0) { 
       sum= sum + first; 
	}
 }
 
 cout << "The sum of all the even numbers of the Fibonacci series less than 4 million is = " << sum <<endl; 
return 0; 
}


