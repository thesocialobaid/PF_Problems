#include <iostream> 
using namespace std; 
int main() { 
int n1; 
int even_count =0; 
int odd_count= 0; 
while(true) { 
    cout << "Enter the Number = "; 
    cin>>n1; 
 if(n1 ==-1){
     break; 
 }
 if(n1%2==0) { 
     even_count++; 
 }
 else { 
     odd_count++; 
 } 
} 
  cout << "The odd numbers are = " << odd_count<<endl; 
  cout << "The even numbers are = "<< even_count<<endl; 
  return 0; 
} 


