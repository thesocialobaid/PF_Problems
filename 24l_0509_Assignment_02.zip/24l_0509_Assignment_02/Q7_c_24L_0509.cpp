#include <iostream>
using namespace std; 
int main() { 
 int starting_number, stopping_number, first=0, second=1, next; 
 
   cout << "Enter from where you want to start the Series = "; 
   cin>> starting_number; 
   cout << "Enter till where you want to end the series = "; 
   cin>> stopping_number; 
   
    if(starting_number <=0 || stopping_number <=0) { 
       cout << "One of the two numbers is invalid and must be greater than zero "; 
	}
   
   
   
   cout << "The Fibonacci series from the number " << starting_number << " to " << stopping_number << "is "; 
   while(second <stopping_number) { 
        next = second; 
        second = first + second; 
        first = next; 
        if(first >start) { 
           cout << first << " "; 
		}
   }

 return 0; 
}

