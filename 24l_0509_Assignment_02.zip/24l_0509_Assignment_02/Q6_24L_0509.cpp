#include <iostream>
using namespace std; 
int main() { 
    int sum_of_numbers = 0; 
     for (int i=501; i<3000 ; i++) {
     	if((i%3==0) || (i%5==0)) && (i%15 !=0) { 
     	   sum_of_numbers = sum_of_numbers + i; 
		 }
	 }
     cout << "The Sum of all the natural numbers greater than 500 and less than 3000 is = " << sum_of_numbers <<endl; 
     
   return 0; 
}
