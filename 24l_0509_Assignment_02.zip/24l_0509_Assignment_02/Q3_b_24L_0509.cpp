#include <iostream>
using namespace std; 
int main() { 
 
  int number;
    bool check_flag;
    int square_value; 

    do {
        cout << "Enter the number to check if it is a perfect square = ";
        cin >> number;
        check_flag = false; 

        for (int i = 1; i * i <= number && check_flag == false; i++) {
            if (number == i * i) {
                check_flag = true;
                square_value= i;
            }
        }

        if (check_flag == true) {
            cout << "The Number is a perfect square  of the  Number " << square_value <<endl; 
        } else {
            cout << "The Number is not a perfect square " << endl;
        }
    } while (number != -1);

    return 0;

return 0 ;
}
